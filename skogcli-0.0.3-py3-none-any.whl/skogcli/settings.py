"""Settings management for SkogCLI."""

import json
import os
import shutil
import time
import typer
from pathlib import Path
from typing import Any, Dict, List, Optional, cast
from rich.console import Console
from rich.syntax import Syntax
from .default_settings import (
    load_default_settings,
    save_default_settings,
    get_default_settings_file,
    CONFIG_VERSION,
    ensure_data_dir,
)

console = Console()

# Create a Typer app for the config commands
config_app = typer.Typer(help="Manage SkogCLI configuration", no_args_is_help=True)

# Ensure the data directory exists
ensure_data_dir()


def get_config_dir() -> Path:
    """Get the configuration directory, creating it if it doesn't exist."""
    # Check for SKOGAI config directory first
    skogai_config_dir = os.getenv("SKOGAI_CONFIG_DIR")
    if skogai_config_dir:
        config_dir = Path(skogai_config_dir)
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir

    # Check config setting
    storage_dir = get_setting("settings.cli.storage_dir")
    if storage_dir:
        config_dir = Path(storage_dir)
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir

    # No .config fallback - raise error instead
    raise ValueError(
        "No configuration directory specified. Set SKOGAI_CONFIG_DIR environment variable "
        "or ensure cli.storage_dir setting is configured in default_settings.json"
    )


def get_backup_dir() -> Path:
    """Get the backup directory for configuration files."""
    backup_dir = get_config_dir() / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    return backup_dir


def get_config_file() -> Path:
    """Get the path to the configuration file."""
    return get_config_dir() / "config.json"


def get_sensitive_config_file() -> Path:
    """Get the path to the sensitive configuration file."""
    return get_config_dir() / "credentials.json"


def create_backup(config_file: Path) -> Optional[Path]:
    """Create a backup of the configuration file."""
    if not config_file.exists():
        return None

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    backup_path = get_backup_dir() / f"{config_file.name}.{timestamp}.bak"

    try:
        shutil.copy2(config_file, backup_path)
        return backup_path
    except Exception as e:
        console.print(f"[bold yellow]Warning:[/] Failed to create backup: {str(e)}")
        return None


def migrate_config(settings: Dict[str, Any]) -> Dict[str, Any]:
    """Migrate configuration from older versions to the current version."""
    # Ensure settings structure exists
    if "settings" not in settings:
        settings["settings"] = {}

    # Check for version in both meta and _meta sections
    has_version = False
    if "meta" in settings["settings"] and "version" in settings["settings"]["meta"]:
        has_version = True
    elif "_meta" in settings["settings"] and "version" in settings["settings"]["_meta"]:
        has_version = True

    if not has_version:
        # This is an old config without versioning
        console.print("[yellow]Migrating configuration to the latest version...[/]")

        # Add metadata section with current version
        settings["settings"]["meta"] = {
            "version": CONFIG_VERSION,
            "last_updated": time.time(),
        }

        # Add new sections that didn't exist in older versions
        if "module" not in settings["settings"]:
            # Initialize empty module settings
            settings["settings"]["module"] = {"history": []}

        if "credentials" not in settings:
            settings["credentials"] = {}

    # Migrate chat history from old location to new location if needed
    if "chat" in settings and "history" in settings["chat"]:
        # Ensure module section exists
        if "module" not in settings["settings"]:
            settings["settings"]["module"] = {}

        # Ensure history section exists in module
        if "history" not in settings["settings"]["module"]:
            settings["settings"]["module"]["history"] = []

        # Copy history from old location to new location
        settings["settings"]["module"]["history"] = settings["chat"]["history"]

    # Handle future migrations based on version numbers
    # version = settings["settings"]["meta"].get("version", 0)

    # Example of future migration:
    # if version < 2:
    #     # Migrate from version 1 to 2
    #     settings["new_section"] = {"new_key": "new_value"}
    #     settings["_meta"]["version"] = 2

    return settings


def load_settings() -> Dict[str, Any]:
    """Load settings from the config file, or create default settings if the file doesn't exist."""
    config_file = get_config_file()

    if not config_file.exists():
        # Create default config
        settings = load_default_settings()
        settings["settings"]["meta"] = {
            "last_updated": time.time(),
            "version": CONFIG_VERSION,
        }
        save_settings(settings)
        return settings

    try:
        with open(config_file, "r") as f:
            settings = json.load(f)

        # Migrate configuration if needed
        settings = migrate_config(settings)

        # Ensure all required sections exist
        defaults = load_default_settings()
        for section, section_defaults in defaults.items():
            if section not in settings:
                settings[section] = section_defaults

        return settings
    except json.JSONDecodeError:
        console.print("[bold red]Error:[/] Config file is corrupted.")

        # Try to restore from backup
        backup = restore_from_latest_backup()
        if backup:
            console.print("[green]Restored configuration from backup.[/]")
            return backup

        # If no backup, reset to defaults
        console.print("[yellow]Resetting to default configuration.[/]")
        settings = load_default_settings()
        if "settings" not in settings:
            settings["settings"] = {}
        if "meta" not in settings["settings"]:
            settings["settings"]["meta"] = {}
        settings["settings"]["meta"]["last_updated"] = time.time()
        save_settings(settings)
        return settings
    except Exception as e:
        console.print(f"[bold red]Error:[/] Failed to load configuration: {str(e)}")
        return load_default_settings()


def load_sensitive_settings() -> Dict[str, Any]:
    """Load sensitive settings like API keys from a separate file."""
    sensitive_file = get_sensitive_config_file()

    if not sensitive_file.exists():
        return {}

    try:
        with open(sensitive_file, "r") as f:
            return cast(Dict[str, Any], json.load(f))
    except Exception:
        console.print(
            "[bold yellow]Warning:[/] Could not load sensitive configuration."
        )
        return {}


def restore_from_latest_backup() -> Optional[Dict[str, Any]]:
    """Attempt to restore configuration from the most recent backup."""
    backup_dir = get_backup_dir()
    if not backup_dir.exists():
        return None

    # Find the most recent backup file
    backup_files = list(backup_dir.glob("config.json.*.bak"))
    if not backup_files:
        return None

    # Sort by modification time (newest first)
    backup_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    # Try to load from the most recent backup
    try:
        with open(backup_files[0], "r") as f:
            return cast(Dict[str, Any], json.load(f))
    except Exception:
        return None


def get_config_keys() -> List[str]:
    """Get a list of all configuration keys for completion."""
    settings = load_settings()

    def extract_keys(data: Dict[str, Any], prefix: str = "") -> List[str]:
        keys = []
        for key, value in data.items():
            full_key = f"{prefix}{key}" if prefix else key
            if isinstance(value, dict):
                keys.append(full_key)
                keys.extend(extract_keys(value, f"{full_key}."))
            else:
                keys.append(full_key)
        return keys

    return cast(List[str], extract_keys(settings))


def save_settings(settings: Dict[str, Any]) -> bool:
    """Save settings to the config file.

    Returns:
        bool: True if successful, False otherwise
    """
    config_file = get_config_file()

    # Update metadata
    if "settings" not in settings:
        settings["settings"] = {}

    if "meta" not in settings["settings"]:
        settings["settings"]["meta"] = {"version": CONFIG_VERSION}

    settings["settings"]["meta"]["last_updated"] = time.time()

    # Create a backup before saving
    create_backup(config_file)

    # Extract sensitive data to save separately
    sensitive_data = settings.get("credentials", {})

    try:
        # Save main configuration
        with open(config_file, "w") as f:
            # Create a copy without sensitive data for the main config file
            main_settings = settings.copy()
            main_settings["credentials"] = {}  # Empty the credentials section
            json.dump(main_settings, f, indent=2)

        # Save sensitive data if there is any
        if sensitive_data:
            sensitive_file = get_sensitive_config_file()
            with open(sensitive_file, "w") as f:
                json.dump(sensitive_data, f, indent=2)

        return True
    except Exception as e:
        console.print(f"[bold red]Error:[/] Failed to save configuration: {str(e)}")
        return False


def get_setting(key: str) -> Any:
    """Get a setting value by its key (supports dot notation for nested settings)."""
    # Check for test environment variable override first (highest priority)
    test_env_key = f"SKOGAI_TEST_{key.upper().replace('.', '_')}"
    env_value = os.getenv(test_env_key)

    if env_value is None:
        # Check for regular environment variable override
        env_key = f"SKOGAI_{key.upper().replace('.', '_')}"
        env_value = os.getenv(env_key)
    if env_value is not None:
        # Try to parse as different types
        if env_value.lower() in ("true", "yes", "1"):
            return True
        elif env_value.lower() in ("false", "no", "0"):
            return False
        elif env_value.lower() in ("null", "none"):
            return None
        try:
            # Try as int
            return int(env_value)
        except ValueError:
            try:
                # Try as float
                return float(env_value)
            except ValueError:
                # Return as string
                return env_value

    settings = load_settings()

    # Handle SkogAI $ syntax - access definitions in the $ section
    if key == "$":
        # Return the entire $ section
        return settings.get("$", {})
    elif key.startswith("$."):
        # Access nested keys within $ section
        dollar_key = key[2:]  # Remove "$." prefix
        dollar_section = settings.get("$", {})

        # Handle nested access like $.claude.hello
        if "." in dollar_key:
            current = dollar_section
            for part in dollar_key.split("."):
                if not isinstance(current, dict) or part not in current:
                    return None
                current = current[part]
            return current
        else:
            return dollar_section.get(dollar_key)

    # Handle credentials separately
    if key.startswith("credentials."):
        sensitive_settings = load_sensitive_settings()
        credential_key = key.split(".", 1)[1]
        return sensitive_settings.get(credential_key)

    if "." in key:
        # Handle nested keys - read directly from root settings (matches set_setting)
        parts = key.split(".")
        current = settings

        for part in parts:
            if part not in current:
                # Fallback: try reading from nested settings.* structure for backward compatibility
                if parts[0] not in ["settings", "credentials"]:
                    fallback_current = settings.get("settings", {})
                    for fallback_part in parts:
                        if fallback_part not in fallback_current:
                            return None
                        fallback_current = fallback_current[fallback_part]
                    return fallback_current
                return None
            current = current[part]
        return current

    # For single keys, read directly from root settings (matches set_setting)
    value = settings.get(key)
    if value is not None:
        return value

    # Fallback: try reading from nested settings.* structure for backward compatibility
    return settings.get("settings", {}).get(key)


def set_setting(key: str, value: Any) -> bool:
    """Set a setting value by its key (supports dot notation for nested settings).

    Returns:
        bool: True if successful, False otherwise
    """
    settings = load_settings()

    # Special handling for credentials
    is_credential = key.startswith("credentials.")

    if is_credential:
        # Load sensitive settings separately
        sensitive_settings = load_sensitive_settings()
        credential_key = key.split(".", 1)[1]
        sensitive_settings[credential_key] = value

        # Save to the sensitive file
        try:
            sensitive_file = get_sensitive_config_file()
            with open(sensitive_file, "w") as f:
                json.dump(sensitive_settings, f, indent=2)

            # Also update the main settings object for consistency
            if "credentials" not in settings:
                settings["credentials"] = {}
            settings["credentials"][credential_key] = value
        except Exception as e:
            console.print(f"[bold red]Error:[/] Failed to save credential: {str(e)}")
            return False
    elif "." in key:
        # Handle nested keys - store directly in root settings
        parts = key.split(".")
        current = settings

        for i, part in enumerate(parts[:-1]):
            if part not in current:
                current[part] = {}
            current = current[part]

        # Set the value at the final level
        current[parts[-1]] = value
    else:
        # For single keys, set directly in root settings
        settings[key] = value

    return save_settings(settings)


def reset_settings() -> bool:
    """Reset settings to default values.

    Returns:
        bool: True if successful, False otherwise
    """
    # Create a backup before resetting
    create_backup(get_config_file())
    create_backup(get_sensitive_config_file())

    # Reset to defaults - load from JSON file
    clean_settings = load_default_settings()

    # Ensure credentials section exists but is empty
    clean_settings["credentials"] = {}

    # Update metadata
    if "settings" not in clean_settings:
        clean_settings["settings"] = {}
    if "_meta" not in clean_settings["settings"]:
        clean_settings["settings"]["_meta"] = {}
    cast(Dict[str, Any], clean_settings["settings"]["_meta"])[
        "last_updated"
    ] = time.time()

    return save_settings(clean_settings)


def add_chat_history_item(item: Dict[str, Any]) -> bool:
    """Add an item to the chat history.

    Args:
        item: A dictionary containing chat history data

    Returns:
        bool: True if successful, False otherwise
    """
    settings = load_settings()

    # Ensure module section exists
    if "settings" not in settings:
        settings["settings"] = {}

    if "module" not in settings["settings"]:
        # Initialize empty module section
        settings["settings"]["module"] = {}

    # Ensure history section exists
    if "history" not in settings["settings"]["module"]:
        settings["settings"]["module"]["history"] = []

    # Add timestamp if not present
    if "timestamp" not in item:
        item["timestamp"] = time.time()

    # Add to history
    settings["settings"]["module"]["history"].append(item)

    # Trim history if it exceeds the maximum
    max_items = settings["settings"]["module"].get("max_history_items", 100)
    if len(settings["settings"]["module"]["history"]) > max_items:
        settings["settings"]["module"]["history"] = settings["settings"]["module"][
            "history"
        ][-max_items:]

    return save_settings(settings)


def get_chat_history(limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """Get the chat history.

    Args:
        limit: Maximum number of items to return (most recent first)

    Returns:
        List of chat history items
    """
    settings = load_settings()

    if (
        "settings" not in settings
        or "module" not in settings["settings"]
        or "history" not in settings["settings"]["module"]
    ):
        return []

    history = settings["settings"]["module"]["history"]

    # Sort by timestamp (newest first)
    history.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

    if limit is not None:
        return history[:limit]

    return history


def clear_chat_history() -> bool:
    """Clear the chat history.

    Returns:
        bool: True if successful, False otherwise
    """
    settings = load_settings()

    if "settings" in settings and "module" in settings["settings"]:
        # Create a backup before clearing
        create_backup(get_config_file())

        # Clear history
        settings["settings"]["module"]["history"] = []
        return save_settings(settings)

    return True


@config_app.callback()
def config_callback() -> None:
    """Manage SkogCLI configuration."""
    pass


@config_app.command("show", help="show configuration")
def show() -> None:
    """Display the current configuration."""
    settings = load_settings()
    json_str = json.dumps(settings, indent=2)
    syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
    console.print(syntax)


@config_app.command("list", help="list configuration")
def list_keys(
    env_only: bool = typer.Option(
        False, "--env-only", help="Show only environment variables (*.env.* keys)"
    )
) -> None:
    """List all available configuration keys with their current values."""
    settings = load_settings()

    def extract_key_value_pairs(
        data: Dict[str, Any], prefix: str = ""
    ) -> List[tuple[str, Any]]:
        pairs = []
        for key, value in data.items():
            full_key = f"{prefix}{key}" if prefix else key
            if isinstance(value, dict):
                pairs.extend(extract_key_value_pairs(value, f"{full_key}."))
            else:
                pairs.append((full_key, value))
        return pairs

    all_pairs = extract_key_value_pairs(settings)

    if env_only:
        # Filter to only show environment variables (*.env.* pattern)
        env_pairs = [(key, value) for key, value in all_pairs if ".env." in key]
        all_pairs = env_pairs

    title = "Environment variables:" if env_only else "Configuration settings:"
    console.print(f"[bold]{title}[/]")
    for key, value in sorted(all_pairs):
        # Format the value for display
        if isinstance(value, str):
            displayed_value = f'"{value}"'
        elif value is None:
            displayed_value = "null"
        else:
            displayed_value = str(value)
        console.print(f"  {key} = {displayed_value}")


@config_app.command("get", help="get configuration")
def get(
    key: str = typer.Argument(
        ...,
        help="Configuration key (e.g., 'memory.page_size')",
        autocompletion=lambda: get_config_keys(),
    ),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Output raw value without formatting"
    ),
    json_format: bool = typer.Option(
        False, "--json", "-j", help="Output as formatted JSON"
    ),
):
    """Get the value of a specific configuration key."""
    value = get_setting(key)
    if value is None:
        console.print(f"[bold red]Error:[/] Key '{key}' not found in configuration.")
        return

    # Check if this is a leaf node in a nested structure
    # is_leaf_node = "." in key and not isinstance(value, dict)

    # Output as JSON when --json flag is used
    if json_format:
        print(json.dumps(value, indent=2))
        return

    # Output raw value for leaf nodes or when --raw flag is used
    if raw:
        print(value)
    elif isinstance(value, dict) or isinstance(value, list):
        json_str = json.dumps(value, indent=2)
        syntax = Syntax(json_str, "json", theme="monokai")
        console.print(syntax)
    else:
        console.print(f"{key} = {value}")


@config_app.command("set", help="set configuration")
def set(
    key: str = typer.Argument(
        ...,
        help="Configuration key (e.g., 'memory.page_size')",
        autocompletion=lambda: get_config_keys(),
    ),
    value: str = typer.Argument(..., help="Value to set"),
):
    """Set the value of a specific configuration key."""
    # Try to parse as JSON first (for objects, arrays, etc.)
    try:
        json_value = json.loads(value)
        set_setting(key, json_value)
        if isinstance(json_value, dict) or isinstance(json_value, list):
            json_str = json.dumps(json_value, indent=2)
            console.print(f"[green]Set[/] {key} = ")
            syntax = Syntax(json_str, "json", theme="monokai")
            console.print(syntax)
        else:
            console.print(f"[green]Set[/] {key} = {json_value}")
        return
    except json.JSONDecodeError:
        # Not valid JSON, continue with other type conversions
        pass

    # Try as int
    try:
        int_value = int(value)
        set_setting(key, int_value)
        console.print(f"[green]Set[/] {key} = {int_value}")
        return 0  # Ensure the command returns 0
    except ValueError:
        pass

    # Try as float
    try:
        float_value = float(value)
        set_setting(key, float_value)
        console.print(f"[green]Set[/] {key} = {float_value}")
        return 0  # Ensure the command returns 0
    except ValueError:
        pass

    # Try as boolean
    if value.lower() in ("true", "yes", "1"):
        set_setting(key, True)
        console.print(f"[green]Set[/] {key} = True")
        return 0  # Ensure the command returns 0
    elif value.lower() in ("false", "no", "0"):
        set_setting(key, False)
        console.print(f"[green]Set[/] {key} = False")
        return 0  # Ensure the command returns 0

    # Try as null/None
    if value.lower() in ("null", "none"):
        set_setting(key, None)
        console.print(f"[green]Set[/] {key} = None")
        return 0  # Ensure the command returns 0

    # Default to string
    set_setting(key, value)
    console.print(f'[green]Set[/] {key} = "{value}"')
    return 0  # Ensure the command returns 0


@config_app.command("reset", help="reset configuration")
def reset(
    confirm: bool = typer.Option(
        False, "--yes", "-y", help="Confirm reset without prompting"
    ),
):
    """Reset configuration to default values."""
    if not confirm:
        should_reset = typer.confirm(
            "Are you sure you want to reset all settings to defaults?"
        )
        if not should_reset:
            console.print("Reset cancelled.")
            return 1  # Ensure the command returns 1 if reset is cancelled

    if reset_settings():
        console.print("[green]Configuration reset to defaults.[/]")
    else:
        console.print("[bold red]Error:[/] Failed to reset configuration.")


@config_app.command("show-defaults", help="show-defaults configuration")
def show_defaults() -> None:
    """Display the default configuration."""
    settings = load_default_settings()
    json_str = json.dumps(settings, indent=2)
    syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
    console.print(syntax)


@config_app.command("edit-defaults", help="edit-defaults configuration")
def edit_defaults(
    key: Optional[str] = typer.Argument(
        None,
        help="Configuration key to edit (if not specified, opens the entire file)",
        autocompletion=lambda: get_config_keys(),
    ),
    value: Optional[str] = typer.Argument(
        None, help="Value to set (if not specified with key, opens the file in editor)"
    ),
):
    """Edit the default configuration."""
    # If key and value are provided, set the specific value
    if key and value is not None:
        defaults = load_default_settings()

        # Try to parse as JSON first (for objects, arrays, etc.)
        try:
            json_value = json.loads(value)

            # Update the defaults
            if "." in key:
                # Handle nested keys
                parts = key.split(".")
                current = defaults
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value at the final level
                current[parts[-1]] = json_value
            else:
                defaults[key] = json_value

            # Save the updated defaults
            if save_default_settings(defaults):
                if isinstance(json_value, dict) or isinstance(json_value, list):
                    json_str = json.dumps(json_value, indent=2)
                    console.print(f"[green]Set default[/] {key} = ")
                    syntax = Syntax(json_str, "json", theme="monokai")
                    console.print(syntax)
                else:
                    console.print(f"[green]Set default[/] {key} = {json_value}")
                return 0
            else:
                console.print("[bold red]Error:[/] Failed to save default settings.")
                return 1
        except json.JSONDecodeError:
            # Not valid JSON, continue with other type conversions
            pass

        # Try as int
        try:
            int_value = int(value)

            # Update the defaults
            if "." in key:
                # Handle nested keys
                parts = key.split(".")
                current = defaults
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value at the final level
                current[parts[-1]] = int_value
            else:
                defaults[key] = int_value

            # Save the updated defaults
            if save_default_settings(defaults):
                console.print(f"[green]Set default[/] {key} = {int_value}")
                return 0
            else:
                console.print("[bold red]Error:[/] Failed to save default settings.")
                return 1
        except ValueError:
            pass

        # Try as float
        try:
            float_value = float(value)

            # Update the defaults
            if "." in key:
                # Handle nested keys
                parts = key.split(".")
                current = defaults
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value at the final level
                current[parts[-1]] = float_value
            else:
                defaults[key] = float_value

            # Save the updated defaults
            if save_default_settings(defaults):
                console.print(f"[green]Set default[/] {key} = {float_value}")
                return 0
            else:
                console.print("[bold red]Error:[/] Failed to save default settings.")
                return 1
        except ValueError:
            pass

        # Try as boolean
        if value.lower() in ("true", "yes", "1"):
            # Update the defaults
            if "." in key:
                # Handle nested keys
                parts = key.split(".")
                current = defaults
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value at the final level
                current[parts[-1]] = True
            else:
                defaults[key] = True

            # Save the updated defaults
            if save_default_settings(defaults):
                console.print(f"[green]Set default[/] {key} = True")
                return 0
            else:
                console.print("[bold red]Error:[/] Failed to save default settings.")
                return 1
        elif value.lower() in ("false", "no", "0"):
            # Update the defaults
            if "." in key:
                # Handle nested keys
                parts = key.split(".")
                current = defaults
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value at the final level
                current[parts[-1]] = False
            else:
                defaults[key] = False

            # Save the updated defaults
            if save_default_settings(defaults):
                console.print(f"[green]Set default[/] {key} = False")
                return 0
            else:
                console.print("[bold red]Error:[/] Failed to save default settings.")
                return 1

        # Try as null/None
        if value.lower() in ("null", "none"):
            # Update the defaults
            if "." in key:
                # Handle nested keys
                parts = key.split(".")
                current = defaults
                for i, part in enumerate(parts[:-1]):
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Set the value at the final level
                current[parts[-1]] = None
            else:
                defaults[key] = None

            # Save the updated defaults
            if save_default_settings(defaults):
                console.print(f"[green]Set default[/] {key} = None")
                return 0
            else:
                console.print("[bold red]Error:[/] Failed to save default settings.")
                return 1

        # Default to string
        # Update the defaults
        if "." in key:
            # Handle nested keys
            parts = key.split(".")
            current = defaults
            for i, part in enumerate(parts[:-1]):
                if part not in current:
                    current[part] = {}
                current = current[part]

            # Set the value at the final level
            current[parts[-1]] = value
        else:
            defaults[key] = value

        # Save the updated defaults
        if save_default_settings(defaults):
            console.print(f'[green]Set default[/] {key} = "{value}"')
            return 0
        else:
            console.print("[bold red]Error:[/] Failed to save default settings.")
            return 1

    # If only key is provided, show the current value
    elif key:
        defaults = load_default_settings()

        # Handle nested keys
        if "." in key:
            parts = key.split(".")
            current_dict: Any = defaults
            for part in parts:
                if part not in current_dict:
                    console.print(
                        f"[bold red]Error:[/] Key '{key}' not found in default configuration."
                    )
                    return 1
                current_dict = current_dict[part]
            value = current_dict
        else:
            if key not in defaults:
                console.print(
                    f"[bold red]Error:[/] Key '{key}' not found in default configuration."
                )
                return 1
            value = defaults[key]

        # Display the value
        if isinstance(value, dict) or isinstance(value, list):
            json_str = json.dumps(value, indent=2)
            console.print(f"Default {key} = ")
            syntax = Syntax(json_str, "json", theme="monokai")
            console.print(syntax)
        else:
            console.print(f"Default {key} = {value}")

        return 0

    # If no key is provided, open the entire file in the editor
    else:
        default_file = get_default_settings_file()

        # Ensure the file exists
        if not default_file.exists():
            defaults = load_default_settings()
            save_default_settings(defaults)

        # Use the EDITOR environment variable, or fall back to common editors
        editor = os.environ.get("EDITOR", "nano")

        try:
            # Use os.system to properly invoke the editor with the file path
            exit_code = os.system(f"{editor} {default_file}")
            if exit_code == 0:
                console.print(
                    "[green]Default configuration file edited successfully.[/]"
                )

                # Validate the edited file
                try:
                    with open(default_file, "r") as f:
                        json.load(f)
                except json.JSONDecodeError as e:
                    console.print(
                        f"[bold red]Warning:[/] The edited file contains invalid JSON: {str(e)}"
                    )
                    console.print(
                        "You may want to fix this by running the edit command again."
                    )
            else:
                console.print(
                    f"[bold red]Error:[/] Editor exited with code {exit_code}"
                )
        except Exception as e:
            console.print(f"[bold red]Error:[/] {str(e)}")


@config_app.command("edit", help="edit configuration")
def edit(
    sensitive: bool = typer.Option(
        False, "--sensitive", "-s", help="Edit sensitive configuration"
    ),
):
    """Open the configuration file in your default editor."""
    config_file = get_sensitive_config_file() if sensitive else get_config_file()

    if not config_file.exists():
        # Create default config if it doesn't exist
        if sensitive:
            with open(config_file, "w") as f:
                json.dump({}, f, indent=2)
        else:
            # Load default settings
            settings = load_default_settings()
            if "settings" not in settings:
                settings["settings"] = {}
            if "meta" not in settings["settings"]:
                settings["settings"]["meta"] = {}
            settings["settings"]["meta"]["last_updated"] = time.time()
            save_settings(settings)

    # Create a backup before editing
    create_backup(config_file)

    # Use the EDITOR environment variable, or fall back to common editors
    editor = os.environ.get("EDITOR", "nano")

    try:
        # Use os.system to properly invoke the editor with the file path
        exit_code = os.system(f"{editor} {config_file}")
        if exit_code == 0:
            console.print("[green]Configuration file edited successfully.[/]")

            # Validate the edited file
            try:
                with open(config_file, "r") as f:
                    json.load(f)
            except json.JSONDecodeError as e:
                console.print(
                    f"[bold red]Warning:[/] The edited file contains invalid JSON: {str(e)}"
                )
                console.print(
                    "You may want to fix this by running the edit command again."
                )
        else:
            console.print(f"[bold red]Error:[/] Editor exited with code {exit_code}")
    except Exception as e:
        console.print(f"[bold red]Error:[/] {str(e)}")


@config_app.command("backup", help="backup configuration")
def backup() -> None:
    """Create a backup of the configuration files."""
    config_file = get_config_file()
    sensitive_file = get_sensitive_config_file()

    backup_paths = []
    if config_file.exists():
        backup_path = create_backup(config_file)
        if backup_path:
            backup_paths.append(backup_path)

    if sensitive_file.exists():
        backup_path = create_backup(sensitive_file)
        if backup_path:
            backup_paths.append(backup_path)

    if backup_paths:
        console.print("[green]Backups created successfully:[/]")
        for path in backup_paths:
            console.print(f"  - {path}")
    else:
        console.print("[yellow]No configuration files to backup.[/]")


@config_app.command("restore", help="restore configuration")
def restore(
    backup_file: Optional[Path] = typer.Argument(
        None,
        help="Path to the backup file (if not specified, uses the most recent backup)",
    ),
    confirm: bool = typer.Option(
        False, "--yes", "-y", help="Confirm restore without prompting"
    ),
):
    """Restore configuration from a backup."""
    if backup_file is None:
        # Find the most recent backup
        backup_dir = get_backup_dir()
        if not backup_dir.exists():
            console.print("[bold red]Error:[/] No backups found.")
            return

        backup_files = list(backup_dir.glob("*.bak"))
        if not backup_files:
            console.print("[bold red]Error:[/] No backups found.")
            return

        # Sort by modification time (newest first)
        backup_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        backup_file = backup_files[0]

    if not backup_file.exists():
        console.print(f"[bold red]Error:[/] Backup file not found: {backup_file}")
        return

    if not confirm:
        should_restore = typer.confirm(
            f"Are you sure you want to restore from {backup_file}?"
        )
        if not should_restore:
            console.print("Restore cancelled.")
            return

    try:
        # Determine target file based on backup filename
        if "credentials" in backup_file.name:
            target_file = get_sensitive_config_file()
        else:
            target_file = get_config_file()

        # Create a backup of the current file before restoring
        create_backup(target_file)

        # Copy the backup to the target file
        shutil.copy2(backup_file, target_file)
        console.print(f"[green]Configuration restored from {backup_file}[/]")

        # Validate the restored file
        try:
            with open(target_file, "r") as f:
                json.load(f)
        except json.JSONDecodeError:
            console.print(
                "[bold red]Warning:[/] The restored file contains invalid JSON."
            )
    except Exception as e:
        console.print(f"[bold red]Error:[/] Failed to restore: {str(e)}")


@config_app.command("list-backups", help="list-backups configuration")
def list_backups() -> None:
    """List available configuration backups."""
    backup_dir = get_backup_dir()
    if not backup_dir.exists():
        console.print("[yellow]No backups found.[/]")
        return

    backup_files = list(backup_dir.glob("*.bak"))
    if not backup_files:
        console.print("[yellow]No backups found.[/]")
        return

    # Sort by modification time (newest first)
    backup_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    console.print("[bold]Available backups:[/]")
    for i, backup in enumerate(backup_files):
        mtime = time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime(backup.stat().st_mtime)
        )
        size = backup.stat().st_size / 1024  # Size in KB
        console.print(f"{i + 1}. {backup.name} ({mtime}, {size:.1f} KB)")


@config_app.command("chat-history", help="chat-history configuration")
def chat_history(
    clear: bool = typer.Option(False, "--clear", help="Clear chat history"),
    limit: int = typer.Option(
        10, "--limit", "-n", help="Number of history items to show"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output in JSON format"
    ),
):
    """Manage chat history."""
    if clear:
        if typer.confirm("Are you sure you want to clear all chat history?"):
            if clear_chat_history():
                console.print("[green]Chat history cleared.[/]")
            else:
                console.print("[bold red]Error:[/] Failed to clear chat history.")
        return

    history = get_chat_history(limit)

    if not history:
        console.print("[yellow]No chat history found.[/]")
        return

    if json_output:
        print(json.dumps(history, indent=2))
        return

    console.print(
        f"[bold]Chat history (showing {len(history)} of {len(get_chat_history())} items):[/]"
    )
    for i, item in enumerate(history):
        timestamp = time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime(item.get("timestamp", 0))
        )
        console.print(f"[bold]{i + 1}. {timestamp}[/]")

        if "session_id" in item:
            console.print(f"  Session: {item['session_id']}")

        if "message" in item:
            console.print(f"  Message: {item['message'][:50]}...")

        if "metadata" in item:
            console.print(f"  Metadata: {json.dumps(item['metadata'], indent=2)}")

        console.print("")


@config_app.command("export-env", help="export environment variables from config")
def export_env(
    namespace: Optional[str] = typer.Option(
        None,
        "--namespace",
        "-n",
        help="Export only variables from specific namespace (e.g., 'claude', 'agent')",
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Write to file instead of stdout"
    ),
) -> None:
    """Export environment variables from configuration.

    This command generates bash export statements for all *.env.* keys in the configuration.

    Examples:
        skogcli config export-env                    # Export all env vars
        skogcli config export-env -n claude          # Export only claude.env.* vars
        skogcli config export-env -o /tmp/env.sh     # Write to file
    """
    settings = load_settings()

    def extract_env_pairs(
        data: Dict[str, Any], prefix: str = ""
    ) -> List[tuple[str, Any]]:
        pairs = []
        for key, value in data.items():
            full_key = f"{prefix}{key}" if prefix else key
            if isinstance(value, dict):
                pairs.extend(extract_env_pairs(value, f"{full_key}."))
            else:
                # Only include keys that match *.env.* pattern
                if ".env." in full_key and value is not None:
                    pairs.append((full_key, value))
        return pairs

    all_env_pairs = extract_env_pairs(settings)

    # Filter by namespace if specified
    if namespace:
        # Support comma-separated namespaces with precedence (later overrides earlier)
        namespaces = [ns.strip() for ns in namespace.split(",")]
        env_dict = {}  # Use dict to handle precedence automatically

        for ns in namespaces:
            filtered_pairs = [
                (key, value)
                for key, value in all_env_pairs
                if key.startswith(f"{ns}.env.")
            ]
            # Add/override variables from this namespace
            for key, value in filtered_pairs:
                parts = key.split(".env.")
                if len(parts) == 2:
                    env_name = parts[1]
                    env_dict[env_name] = value

        # Convert back to pairs format for consistency
        all_env_pairs = [
            (f"*.env.{env_name}", value) for env_name, value in env_dict.items()
        ]

    if not all_env_pairs:
        msg = "No environment variables found"
        if namespace:
            msg += f" in namespace '{namespace}'"
        console.print(f"[yellow]{msg}.[/]")
        return

    # Generate export statements
    export_lines = []
    for key, value in sorted(all_env_pairs):
        # Extract the environment variable name from the key
        # e.g., "claude.env.MYENV" -> "MYENV"
        parts = key.split(".env.")
        if len(parts) == 2:
            env_name = parts[1]
            # Escape value for shell safety
            escaped_value = str(value).replace('"', '\\"')
            export_line = f'export {env_name}="{escaped_value}"'
            export_lines.append(export_line)

    # Output to file or stdout
    if output:
        try:
            output_path = Path(output)
            output_path.write_text("\n".join(export_lines) + "\n")
            console.print(f"[green]Environment variables exported to:[/] {output_path}")
        except Exception as e:
            console.print(f"[bold red]Error:[/] Failed to write to {output}: {str(e)}")
            return
    else:
        # Print to stdout
        for line in export_lines:
            print(line)
